<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut" href="<?php bloginfo('template_directory') ?>/assets/img/favicon.png">
    <link rel="stylesheet" href="<?php bloginfo('template_directory') ?>/assets/css/icons.css">
    <link rel="stylesheet" href="<?php bloginfo('template_directory') ?>/assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="<?php bloginfo('template_directory') ?>/assets/css/owl.theme.css">
    <link rel="stylesheet" href="<?php bloginfo('template_directory') ?>/assets/css/bootstrap.min.css">
		<?php wp_head() ?>
    <link rel="stylesheet" href="<?php bloginfo('template_directory') ?>/style.css">
		<!-- Google Tag Manager -->
		<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
		new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
		j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
		'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
		})(window,document,'script','dataLayer','GTM-KBXFLGK');</script>
		<!-- End Google Tag Manager -->
</head>
<body <?php body_class('body-wrapper') ?>>
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-KBXFLGK"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
<header class="header-wrap header-style">
	<div class="top-header d-none d-md-block">
		<div class="container-flud">
			<div class="row">
				<div class="col-md-7 pr-md-0 col-12">
					<div class="header-cta">
						<ul>
							<li>
								<a href="mailto:letstalk@growtalitygroup.com"><i class="fal fa-envelope"></i> letstalk@growtalitygroup.com</a>
							</li>
							<li>
								<a href="tel:+971559524907"><i class="fal fa-phone"></i> +971 55 952 4907</a>
							</li>
						</ul>
					</div>
				</div>
				<div class="col-md-5 col-12">
					<div class="header-right-cta d-flex justify-content-end">
						<div class="social-profile mr-30">
							<a href="https://facebook.com/growtalitygroup"><i class="fab fa-facebook-f"></i></a>
							<a href="https://twitter.com/growtalitygroup"><i class="fab fa-twitter"></i></a>
							<a href="https://instagram.com/growtalitygroup"><i class="fab fa-instagram"></i></a>
							<a href="https://youtube.com/channel/UCBm31AvIDJ9B0IMke5RFuTw"><i class="fab fa-youtube"></i></a>
							<a href="https://linkedin.com/company/growtality-group"><i class="fab fa-linked-in"></i></a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div class="main-header-wraper">
		<div class="container-fluid">
			<div class="row align-items-center justify-content-between">
				<div class="header-logo">
					<div class="logo">
						<a href="/">
							<img src="<?php bloginfo('template_directory') ?>/assets/img/logo-2.png" alt="logo">
						</a>
					</div>
				</div>
				<div class="header-menu d-none d-xl-block">
					<div class="main-menu">
						<ul>
							<li><a href="#">Services <i class="fas fa-angle-down"></i></a>
								<ul class="sub-menu">
									<li><a href="/branding/">Branding</a></li>
									<li><a href="/online-advertising/">Online Ads</a></li>
									<li><a href="/seo/">Seo and Content</a></li>
									<li><a href="/web-design/">Web Development</a></li>
									<li><a href="/digital-consultancy/">Digital Consultancy</a></li>
									<li><a href="/social-media-management/">Social Media Services</a></li>
								</ul>
							</li>
							<li><a href="/projects/">Projects</a></li>
							<li><a href="/blog/">Blog</a></li>
							<li><a href="/about/">About</a></li>
							<li><a href="/contact/">Contact</a></li>
						</ul>
					</div>
				</div>
				<div class="header-right d-flex align-items-center">
					<div class="header-btn-cta">
						<a href="/digital-consultancy/" class="theme-btn">Creative Studio <i class="fas fa-arrow-right"></i></a>
					</div>
					<div class="mobile-nav-bar d-block ml-3 ml-sm-5 d-xl-none">
						<div class="mobile-nav-wrap">                    
							<div id="hamburger">
								<i class="fal fa-bars"></i>
							</div>
							<div class="mobile-nav">
								<button type="button" class="close-nav">
									<i class="fal fa-times-circle"></i>
								</button>
								<nav class="sidebar-nav">
									<ul class="metismenu" id="mobile-menu">
										<li><a class="has-arrow" href="#">Services</a>
											<ul class="sub-menu">
												<li><a href="/branding/">Branding</a></li>
												<li><a href="/online-advertising/">Online Ads</a></li>
												<li><a href="/seo/">Seo and Content</a></li>
												<li><a href="/web-design/">Web Development</a></li>
												<li><a href="/digital-consultancy/">Digital Consultancy</a></li>
												<li><a href="/social-media-management/">Social Media Services</a></li>
											</ul>
										</li>
										<li><a href="/projects/">Projects</a></li>
										<li><a href="/blog/">Blog</a></li>
										<li><a href="/about/">About</a></li>
										<li><a href="/contact/">Contact</a></li>
									</ul>
								</nav>
	
								<div class="action-bar">
									<a href="mailto:letstalk@growtalitygroup.com"><i class="fal fa-envelope-open-text"></i>letstalk@growtalitygroup.com</a>
									<a href="tel:+971559524907"><i class="fal fa-phone"></i>+971 55 952 4907</a>
									<a href="/digital-consultancy/" class="d-btn theme-btn black">Creative Studio</a>
								</div>
							</div>                            
						</div>
						<div class="overlay"></div>
					</div>
				</div>
			</div>
		</div>
	</div>
</header>