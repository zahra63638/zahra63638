<?php get_header() ?>
<section class="page-banner-wrap bg-cover" style="background-image: url('<?php bloginfo('template_directory') ?>/assets/img/page-banner.jpg')">
	<div class="container">
		<div class="row align-items-center">
			<div class="col-md-12 col-12">
				<div class="page-heading text-white">
					<div class="page-title">
						<h1>404 not found!</h1>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<section class="single-style container">the website you were trying to reach couldn't be found on the server</section>
<?php get_footer() ?>