<?php get_header() ?>
<section class="page-banner-wrap bg-cover" style="background-image: url('<?php the_post_thumbnail_url() ?>')">
	<div class="container">
		<div class="row align-items-center">
			<div class="col-md-12 col-12">
				<div class="page-heading text-white">
					<div class="page-title">
						<h1><?php the_title() ?></h1>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

<section class="blog-wrapper news-wrapper section-padding">
	<div class="container">
		<div class="row">
			<div class="col-12">
				<div class="blog-post-details border-wrap">
					<div class="single-blog-post post-details">                            
						<div class="post-content">
							<div class="post-meta">
								<span><i class="fal fa-calendar-alt"></i><?php echo get_the_date('Y/m/d') ?></span>
							</div>
							<?php the_content() ?>	
						</div>
					</div>
					<div class="row tag-share-wrap">
						<div class="col-lg-6 col-12">
							<h4>Social Share</h4>
							<div class="social-share">
								<a href="https://www.facebook.com/sharer/sharer.php?u=<?php the_permalink() ?>"><i class="fab fa-facebook-f"></i></a>
								<a href="https://twitter.com/share?text=<?php the_title() ?>&url=<?php the_permalink() ?>"><i class="fab fa-twitter"></i></a>
								<a href="#https://t.me/share/url?url=<?php echo home_url( $wp->request ) ?>"><i class="fab fa-telegram"></i></a>
								<a href="https://www.linkedin.com/shareArticle?mini=true&url=<?php the_permalink() ?>&title=<?php the_title() ?>"><i class="fab fa-linkedin-in"></i></a>                                    
							</div>
						</div>
						<div class="col-lg-6 col-12"></div>
						<hr>
					</div>

					<div class="related-post-wrap">
						<h3>Releted Post</h3>
						<div class="row">
							<?php
								$term = get_field('blog_selector');
								$args = array(
									'post_type' => 'blog',
									'posts_per_page' => 4,
									'tax_query' => array(
										array (
											'taxonomy' => 'blog-cat',
											'field' => 'term_id',
											'terms' => $term,
										)
									),
								);
								$query = new WP_Query( $args );
								if ( $query->have_posts() ) {
									while ( $query->have_posts() ) {
										$query->the_post();
							?>
							<div class="col-md-6 col-12">
								<div class="single-related-post">
									<div class="featured-thumb bg-cover" style="background-image: url('<?php the_post_thumbnail_url() ?>')"></div>
									<div class="post-content">
										<h4><a href="<?php the_permalink() ?>"><?php the_title() ?></a></h4>
									</div>
								</div>
							</div>
							<?php
									}
								}
								wp_reset_postdata();
							?>
						</div>
					</div>
					<div class="comments-section-wrap pt-40">
						<?php comments_template() ?>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<?php get_footer() ?>