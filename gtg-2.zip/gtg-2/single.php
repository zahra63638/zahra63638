<?php get_header() ?>
<section class="page-banner-wrap bg-cover" style="background-image: url('<?php the_post_thumbnail_url() ?>')">
	<div class="container">
		<div class="row align-items-center">
			<div class="col-md-12 col-12">
				<div class="page-heading text-white">
					<div class="page-title">
						<h1><?php the_title() ?></h1>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

<section class="service-details-post-wrapper section-padding">
	<div class="container">
		<div class="row">
			<div class="col-12">
				<div class="service-details-content">
					<?php the_content() ?>					
				</div>
			</div>
		</div>
	</div>
</section>
<?php get_footer() ?>