<?php get_header() ?>
<section class="page-banner-wrap bg-cover" style="background-image: url('<?php the_post_thumbnail_url() ?>')">
	<div class="container">
		<div class="row align-items-center">
			<div class="col-md-12 col-12">
				<div class="page-heading text-white">
					<div class="page-title">
						<p>Who We Are?</p>
						<h1 style="margin:1rem 0">About Growtality</h1>
						<p>SHALL WE BEGIN THE EXPLORATION</p>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

<section class="about-us-wrapper section-padding">
	<div class="container">
		<div class="row">
			<div class="col-12 pr-5">
				<p class="pr-lg-5">Everything in our world is a combination of some elements. This is how great things are made. In fact, our entire world is a magical combination of elements with unique qualities that made LIFE possible together. Now humans, as the product of this universe, can join the cause and create more beautiful combinations. And this is why Growtality came to existence, to bring value to the lives and businesses around it, by having a perfect combination of people with passion, curiosity, knowledge, and of course, the desire to create. <br>
				Our team, the magical elements of this company, each gave their unique qualities to make it possible for Growtality to live and do magic. So we wake up every day to combine things, to solve problems, to make value, and to bring GROWTH. <br>
				And we do all that with love, among the amazing people of North America, Europe, Singapore, Dubai, and sooner than later, in many other regions or perhaps, planets.
				We, as a creative digital agency, look at every service of this company as an element of progress in creating a digital world. And we all know how vast these worlds will be in 2030. Therefore, every detail, every corner, and every experience matters when you are designing your digital world, whether it’s located on your website, your social media, or maybe the metaverse. And that’s exactly why all of our services are set to be the cornerstone for that purpose.<br>
				The people of Growtality love to think that with the right combination of knowledge and passionate effort, every idea can come to life, blossom, and grow into a world on its own. <br>
				<strong>Now the question is; how do you want to create your world?</strong> <br>
				<strong>What are the magical combinations that you are looking for?</strong></p>
			</div>
		</div>
	</div>
</section>  

<?php
get_template_part('section/funfact');
get_template_part('section/client');
?>
<?php get_footer() ?>