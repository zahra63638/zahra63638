﻿<?php get_header() ?>   
<section class="page-banner-wrap bg-cover" style="background-image: url('<?php bloginfo('tempate_directory') ?>assets/img/page-banner.jpg')">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-12 col-12">
                <div class="page-heading text-white">
                    <div class="page-title">
                        <h1><?php wp_title() ?></h1>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="blog-wrapper news-wrapper section-padding">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="blog-posts">
                    <?php
                        $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
                        $args = array(
                        'post_type'         => 'blog',
                        'orderby'           => 'date',
                        'order'             => 'DESC',
                        'post_status'       => 'publish',
                        'posts_per_page'    => 12,
                        'paged'             => $paged,
                        );
                        $q = new WP_Query( $args );
                        if ( $q->have_posts() ) {
                        while ( $q->have_posts() ) {
                            $q->the_post();
                    ?>
                    <div class="single-blog-post">
                        <div class="post-featured-thumb bg-cover" style="background-image: url('<?php the_post_thumbnail_url() ?>')"></div>
                        <div class="post-content">
                            <h2><a href="<?php the_permalink() ?>"><?php the_title() ?></a></h2>
                            <div class="post-meta">
                                <span><i class="fal fa-calendar-alt"></i><?php echo get_the_date('Y/m/d') ?></span>
                            </div>
                            <p><?php the_excerpt() ?></p>
                            <div class="d-flex justify-content-between align-items-center mt-30">
                                <div class="post-link">
                                    <a href="<?php the_permalink() ?>"><i class="fal fa-arrow-right"></i> Read More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
                        wp_reset_postdata();
                        }
                    }
                    ?>
                </div>
                <div class="page-nav-wrap mt-60 text-center">
                    <?php wp_pagenavi( array( 'query' => $q )); ?>
                </div>
            </div>
        </div>
    </div>
</section>
<?php get_footer() ?>