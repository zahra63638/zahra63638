<?php get_header() ?>
<section class="page-banner-wrap bg-cover" style="background-image: url('<?php the_post_thumbnail_url() ?>')">
	<div class="container">
		<div class="row align-items-center">
			<div class="col-md-12">
				<div class="page-heading text-white">
					<div class="sub-title">
						<h4>Love to hear from you</h4>
					</div>
					<div class="page-title" style="margin-top:1.5rem">
						<h1>Contact Growtality</h1>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

<section class="about-us-wrapper section-padding">
	<div class="container">
		<div class="row">
			<div class="col-12 pr-5">
				<p class="pr-lg-5">
					<strong>How do you want your digital world to be?</strong> <br>
					<strong>Why we ask?</strong> <br>
					Because creating a digital experience is what we absolutely love to do as a creative digital agency. And we put all of our knowledge and creativity to work, in order to combine the right digital ingredients that lead to creating the experience and the world you have in mind. <br>
					So, grab your coffee, take a seat, and tell us about it. We can’t wait to know more.
					We can start our conversation with a little chitchat on WhatsApp, Or an email, as traditions say.
					Or perhaps a friendly visit to our office. <br>
					<strong>But remember that no matter which way you choose to reach us, we love to hear your thoughts, so do us the favor and let’s begin.</strong>
				</p>
			</div>
		</div>
	</div>
</section>

<section class="contact-page-wrap">
	<div class="container">
		<div class="row">
			<div class="col-lg-4 col-md-6 col-12">
				<div class="single-contact-card card1">
					<div class="top-part">
						<div class="icon">
							<img src="https://growtalitygroup.com/wp-content/uploads/2022/08/uae.png" alt="">
						</div>
						<div class="title">
							<h4>Dubai</h4>
							<span>Centeral office</span>
						</div>
					</div>
					<div class="bottom-part">                            
						<div class="info">
							<p>Phone:</p>
							<a href="tel:+971559524907" title="uae tell">+97155 952 4907</a>
						</div>
						<div class="icon">
							<i class="fal fa-arrow-right"></i>
						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-md-6 col-12">
				<div class="single-contact-card card1">
					<div class="top-part">
						<div class="icon">
						<img src="https://growtalitygroup.com/wp-content/uploads/2022/08/spain.png" alt="">
						</div>
						<div class="title">
							<h4>Spain</h4>
							<span>EU office</span>
						</div>
					</div>
					<div class="bottom-part">                            
						<div class="info">
							<p>Phone:</p>
							<a href="tel:+34960195105" title="uae tell">+349 6019 51 05</a>
						</div>
						<div class="icon">
							<i class="fal fa-arrow-right"></i>
						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-md-6 col-12">
				<div class="single-contact-card card1">
					<div class="top-part">
						<div class="icon">
							<img src="https://growtalitygroup.com/wp-content/uploads/2022/08/ca.png" alt="">
						</div>
						<div class="title">
							<h4>Canada</h4>
							<span>North America office</span>
						</div>
					</div>
					<div class="bottom-part">                            
						<div class="info">
							<p>Phone:</p>
							<a href="tel:tel:+14168771532" title="uae tell">+1 416 8771 532</a>
						</div>
						<div class="icon">
							<i class="fal fa-arrow-right"></i>
						</div>
					</div>
				</div>
			</div>
		</div>

		<div class="row">
			<div class="col-12 col-lg-12">
				<div class="contact-map-wrap">
					<div id="map">
						<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d14440.596868555409!2d55.2819193!3d25.1981899!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x7647f94c66efc545!2sBLACK%20AND%20BLANC%20-%20Flowers%20Shop%20-%20Dubai%20Mall%20-%20Dubai!5e0!3m2!1sen!2s!4v1672733896171!5m2!1sen!2s" frameborder="0" style="border:0; width:100%" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
					</div>
				</div>
			</div>
		</div>

		<div class="row section-padding pb-0">
			<div class="col-12 text-center mb-20">
				<div class="section-title">
					<h1>let's Talk</h1>
				</div>
			</div>

			<div class="col-12 col-lg-12">
				<div class="contact-form" style="margin-bottom:2rem">
					<?php echo do_shortcode('[wpforms id="1506"]') ?>
				</div>
			</div>
		</div>
	</div>
</section>
<?php get_footer() ?>