<?php get_header() ?>
<section class="page-banner-wrap bg-cover" style="background-image: url('<?php bloginfo('template_directory') ?>/assets/img/page-banner.jpg')">
	<div class="container">
		<div class="row align-items-center">
			<div class="col-md-12 col-12">
				<div class="page-heading text-white">
					<div class="page-title">
						<h1><?php the_title() ?></h1>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<section class="single-style container"><?php the_content() ?></section>
<?php get_footer() ?>