<section class="funfact-wrapper bottom text-white">
    <div class="container">
        <div class="funfact-content-grid bg-cover" style="background-image: url('<?php bloginfo('template_directory') ?>/assets/img/funfact-line.png')">
            <div class="single-funfact-item">
                <div class="icon">
                    <i class="fal fa-gem"></i>
                </div>
                <h3>36</h3>
                <p>Project Completed</p>
            </div>
            <div class="single-funfact-item">
                <div class="icon">
                    <i class="fal fa-drafting-compass"></i>
                </div>
                <h3>85</h3>
                <p>Expert Consultants</p>
            </div>
            <div class="single-funfact-item">
                <div class="icon">
                    <i class="fal fa-stars"></i>
                </div>
                <h3>60</h3>
                <p>5 Stars Rating</p>
            </div>
            <div class="single-funfact-item">
                <div class="icon">
                    <i class="fal fa-trophy-alt"></i>
                </div>
                <h3>430</h3>
                <p>Link 1 Google</p>
            </div>
        </div>
    </div>
</section>