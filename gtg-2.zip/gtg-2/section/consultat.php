<section class="consultations-wrapper section-padding bg-contain pb-0" style="background-image: url('<?php bloginfo('template_directory') ?>/assets/img/circle-bg-2.png')">
    <div class="container">
        <div class="row">
            <div class="col-12 col-lg-6 col-xl-5">
                <h1>Get Consultant Fast<br> -> 30 min free </h1>
                <p class="mt-3">Get your free 30 minutes strategy session with an experienced digital marketer valued at AED1,000.</p>

                <div class="call-consultation mt-30 mb-40">
                    <div class="icon">
                        <i class="fal fa-phone-plus"></i>
                    </div>
                    <div class="content">
                        <span>Call us at</span>
                        <h5><a href="tel:+971 55 952 4907">+971 55 952 4907</a></h5>
                    </div>
                </div>
            </div>

            <div class="col-12 col-lg-6 col-xl-6 offset-xl-1">
                <div class="consultations-form text-white">
                    <p>let’s talk with us</p>
                    <h1>Free Consultations</h1>
                    <?php echo do_shortcode('[wpforms id="1485"]') ?>
                </div>
            </div>
        </div>
    </div>
</section>