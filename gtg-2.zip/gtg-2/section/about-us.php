<section class="about-us-wrapper section-padding">
    <div class="container">
        <div class="row">
            <div class="col-xl-6 col-lg-6 col-12 pr-xl-5">
                <div class="section-title mb-30">
                    <p>About GrowTality</p>
                    <h1>4 Years Of Experience <br> In Web Solutions</h1>
                </div>

                <p class="pr-md-5">Everything in our world is a combination of some elements. This is how great things are made. In fact, our entire world is a magical combination of elements with unique qualities that made LIFE possible together. Now humans, as the product of this universe, can join the cause and create more beautiful combinations.</p>
                
                <div class="about-check-list d-flex">
                    <div class="banner bg-cover" style="background-image: url('<?php bloginfo('template_directory') ?>/assets/img/about_list.jpg')"></div>

                    <ul class="checked-list">
                        <li>Web Engineering</li>
                        <li>Digital Services</li>
                        <li>Web Consultancy</li>
                        <li>Web Software</li>
                    </ul>
                </div>
            </div>

            <div class="col-xl-6 col-md-10 col-lg-6 pl-xl-5 col-12 mt-5 mt-xl-0">
                <div class="about-thum">
                    <div class="item top-image text-right">
                        <img src="<?php bloginfo('template_directory') ?>/assets/img/about-big-thumb-1.jpg" alt="">
                    </div>
                    <div class="item bottom-image">
                        <img src="<?php bloginfo('template_directory') ?>/assets/img/about-big-thumb-2.jpg" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>