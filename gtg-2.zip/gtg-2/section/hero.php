<section class="hero-2">
    <div class="single-slide bg-cover" style="background-image: url('<?php bloginfo('template_directory') ?>/assets/img/slide2.jpg')">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12 col-lg-10 col-xl-8">
                    <div class="hero-contents">
                        <h1>DIGITAL MARKETING AGENCY</h1>
                        <p>Professional Agency Services</p>
                        <a href="" class="theme-btn">Start Talk <i class="fas fa-arrow-right"></i></a>
                        <a href="" class="theme-btn minimal-btn">About US <i class="fas fa-arrow-right"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>