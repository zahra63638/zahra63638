<section class="services-wrapper service-2 section-padding section-bg bg-contain" style="background-image: url('<?php bloginfo('template_directory') ?>/assets/img/circle-bg.png')">
    <div class="container">
        <div class="row mb-50">
            <div class="col-12 col-lg-12">
                <div class="section-title text-white text-center">
                    <p>Popular Web Services</p>
                    <h1>Some Our Services</h1>
                </div>
            </div>
        </div>
        <div class="row">
            <?php
                $query = new WP_Query( 
                    array(
                        'post_type'			=> 'post',
                        'posts_per_page'	=> 3,
                        'orderby' 			=> 'date',
                    )
                );
                if ( $query->have_posts() ) {
                    while ( $query->have_posts() ) {
                        $query->the_post();
            ?>
            <div class="col-md-6 col-xl-4 col-12">
                <div class="single-service-box">
                    <div class="icon bg-cover" style="background-image: url('<?php the_post_thumbnail_url() ?>')"></div>
                    <div class="content-visible">
                        <h4><a href="<?php the_permalink() ?>"><?php the_title() ?></a></h4>
                    </div>
                </div>
            </div>
            <?php
                }
                wp_reset_postdata();
                }
            ?>
        </div>
    </div>
</section>