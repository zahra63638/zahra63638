<section class="testimonial-wrapper pt-50 pb-110">
    <div class="container">
        <div class="row">
            <div class="col-12 col-lg-12">
                <div class="testimonial-carousel-2 owl-carousel owl-theme">
                    <div class="single-testimonial active">
                        <div class="icon">
                            <i class="flaticon-right-quote"></i>
                        </div>
                        <h2>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Commodi perspiciatis natus cumque harum, nulla sapiente aliquam!</h2>
                        <div class="client-info">
                            <div class="client-img bg-cover" style="background-image: url('<?php bloginfo('template_directory') ?>/assets/img/home1/testi1.jpg')"></div>
                            <div class="client-bio">
                                <h3>Ehsan</h3>
                                <p>Manager</p>
                            </div>
                        </div>
                    </div>

                    <div class="single-testimonial">
                        <div class="icon">
                            <i class="flaticon-right-quote"></i>
                        </div>
                        <h2>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Commodi perspiciatis natus cumque harum, nulla sapiente aliquam!</h2>
                        <div class="client-info">
                            <div class="client-img bg-cover" style="background-image: url('<?php bloginfo('template_directory') ?>/assets/img/home1/testi1.jpg')"></div>
                            <div class="client-bio">
                                <h3>Ehsan</h3>
                                <p>Manager</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>