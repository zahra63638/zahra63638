<section class="case-study-carousel-wrapper">
    <div class="title-sec">BLOG</div>
    <div class="container text-center">
        <div class="case-study-items owl-carousel">
            <?php
				$query = new WP_Query( 
					array(
						'post_type'			=> 'blog',
						'posts_per_page'	=> 6,
						'orderby' 			=> 'date',
					)
				);
				if ( $query->have_posts() ) {
					while ( $query->have_posts() ) {
						$query->the_post();
			?>
            <div class="single-case-item">
                <div class="case-thumb bg-cover" style="background-image: url('<?php the_post_thumbnail_url() ?>')"></div>
                <div class="contents">
                    <div class="content-visible">
                        <a href="<?php the_permalink() ?>"><h3><?php the_title() ?></h3></a>
                        <span><?php the_category(', ') ?></span>
                    </div>
                </div>
            </div>
            <?php
				}
				wp_reset_postdata();
				}
			?>
        </div>
    </div>
</section>