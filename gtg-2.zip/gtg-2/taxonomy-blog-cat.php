<?php get_header() ?>   
<section class="page-banner-wrap bg-cover" style="background-image: url('<?php bloginfo('tempate_directory') ?>assets/img/page-banner.jpg')">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-12 col-12">
                <div class="page-heading text-white">
                    <div class="page-title">
                        <h1><?php single_cat_title() ?></h1>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="case-study-wrapper section-padding">
    <div class="container">
        <div class="row case-study-2">
            <?php if ( have_posts() ) : ?>
		<?php while ( have_posts() ) : the_post(); ?>
            <div class="col-md-6 col-xl-4 col-12">
                <div class="single-case-item">
                    <div class="case-thumb bg-cover" style="background-image: url('<?php the_post_thumbnail_url() ?>')"></div>
                    <div class="contents">
                        <div class="content-visible">
                            <h3><a href="<?php the_permalink() ?>"><?php the_title() ?></a></h3>
                        </div>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>
		<?php endif; ?>
        </div>
        <div class="page-nav-wrap mt-60 text-center">
            <?php wp_pagenavi( array( 'query' => $q )); ?>
        </div>
    </div>
</section>
<?php get_footer() ?>