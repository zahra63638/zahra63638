<section class="cta-banner">
    <div class="container-fluid bg-cover section-bg" style="background-image: url('<?php bloginfo('template_directory') ?>/assets/img/cta_bg1.png')">
        <div class="cta-content">
            <div class="row align-items-center">
                <div class="col-xl-7 text-white col-12 text-center text-xl-left">
                    <h1>Let's Talk Now!</h1>
                </div>
                <div class="col-xl-5 col-12 text-center text-xl-right">
                    <a href="" class="theme-btn mt-4 mt-xl-0">Contact Us <i class="fas fa-arrow-right"></i></a>
                    <a href="" class="ml-sm-3 mt-4 mt-xl-0 theme-btn minimal-btn">About Us <i class="fas fa-arrow-right"></i></a>
                </div>
            </div>
        </div>
    </div>
</section>

<footer class="footer-2 footer-wrap">
	<div class="footer-widgets">            
		<div class="container">
			<div class="row justify-content-between">
				<div class="col-md-6 col-xl-3 col-12 pr-xl-4">
					<div class="single-footer-wid site_footer_widget">
						<a href="/">
							<img src="<?php bloginfo('template_directory') ?>/assets/img/logo.png" alt="logo">
						</a>
						<div><?php the_field('footer_title', 'option') ?></div>
						<p class="mt-4"><?php the_field('footer_description', 'option') ?></p>
						<div class="social-link mt-30">
							<a href="<?php the_field('facebook', 'option') ?>"><i class="fab fa-facebook-f"></i></a>
							<a href="<?php the_field('twitter', 'option') ?>"><i class="fab fa-twitter"></i></a>
							<a href="<?php the_field('instagram', 'option') ?>"><i class="fab fa-instagram"></i></a>
							<a href="<?php the_field('youtube', 'option') ?>"><i class="fab fa-youtube"></i></a>
						</div>
					</div>
				</div>
				<div class="col-md-6 col-xl-2 col-12">                        
					<div class="single-footer-wid">
						<div class="wid-title">
							<h4>Usefull Links</h4>
						</div>
						<ul>
							<?php
								$menuParameters = array(
									'theme_location'  => 'footer_menu',
									'container'       => false,
									'echo'            => false,
									'items_wrap'      => '%3$s',
									'depth'           => 0,
								);
								echo strip_tags(wp_nav_menu( $menuParameters ), '<li><a>' );
							?>
						</ul>
					</div>
				</div>
				<div class="col-md-6 col-xl-2 col-12">
					<div class="single-footer-wid">
						<div class="wid-title">
							<h4>Usefull Links</h4>
						</div>
						<ul>
							<?php
								$menuParameters = array(
									'theme_location'  => 'footer_services_menu',
									'container'       => false,
									'echo'            => false,
									'items_wrap'      => '%3$s',
									'depth'           => 0,
								);
								echo strip_tags(wp_nav_menu( $menuParameters ), '<li><a>' );
							?>
						</ul>
					</div>
				</div>
				<div class="col-md-6 col-xl-3 col-12">
					<div class="single-footer-wid recent_post_widget">
						<div class="wid-title">
							<h4>Recent Blog</h4>
						</div>
						<div class="recent-post-list">
							<?php
								$query = new WP_Query( 
									array(
										'post_type'			=> 'blog',
										'posts_per_page'	=> 3,
										'orderby' 			=> 'date',
									)
								);
								if ( $query->have_posts() ) {
									while ( $query->have_posts() ) {
										$query->the_post();
							?>
							<div class="single-recent-post">
								<div class="thumb bg-cover" style="background-image: url('<?php the_post_thumbnail_url() ?>')"></div>
								<div class="post-data">
									<span><i class="fal fa-calendar-alt"></i><?php echo get_the_date('Y/m/d') ?></span>
									<h5><a href=""><?php the_title() ?></a></h5>
								</div>
							</div>
							<?php
								}
								wp_reset_postdata();
								}
							?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div class="footer-bottom">
		<div class="container text-center">
			<div class="footer-bottom-content">
				© 2021 GrowTality All Rights Reserved.
			</div>
		</div>
	</div>
</footer>
<script src="<?php bloginfo('template_directory') ?>/assets/js/app.js"></script>
<?php wp_footer() ?>
</body>
</html>