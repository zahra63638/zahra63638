<?php
get_header();
$term = get_queried_object();
$title = get_field('heading_h1', $term);
$thumb = get_field('category_thumbnail', $term);
$why_title = get_field('why_title', $term);
$why_description = get_field('why_description', $term);
?>
<section class="page-banner-wrap bg-cover" style="background-image: url('<?php echo $thumb ?>')">
	<div class="container">
		<div class="row align-items-center">
			<div class="col-md-12 col-12">
				<div class="page-heading text-white">
					<div class="page-title">
						<h1><?php echo $title ?></h1>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

<section class="servces-wrapper section-padding">
	<div class="container">
		<div class="row text-center mb-30">
			<div class="col-lg-8 p-lg-0 col-12 offset-lg-2">
				<div class="section-title"><?php echo $why_title ?></div>
				<p class="mt-20"><?php echo $why_description ?></p>
			</div>
		</div>

		<div class="row justify-content-between">
			<?php if( have_rows('logos', $term) ): ?>
			<?php while( have_rows('logos', $term) ): the_row() ?>
			<div class="col-lg-2 col-md-3 col-6">
				<div class="single-service">
					<div class="icon">
						<img src="<?php the_sub_field('image', $term) ?>">
					</div>
				</div>
			</div>
			<?php endwhile ?>
			<?php endif ?>
		</div>
	</div>
</section>  

<section class="services-wrapper service-1 section-padding section-bg">
	<div class="container">
		<div class="row mb-50">
			<div class="col-12 col-lg-12">
				<div class="section-title text-white text-center">
					Plans
					<p style="margin-top:1rem">see all plans</p>
				</div>
			</div>
		</div>
		<div class="row">
			<?php if( have_rows('price_plans', $term) ): ?>
			<?php while( have_rows('price_plans', $term) ): the_row() ?>
			<div class="col-md-4 col-xl-4 col-12">
				<div class="single-service-item">
					<h4><?php the_sub_field('table_name', $term) ?></h4>
					<ul>
						<?php if( have_rows('items', $term) ): ?>
						<?php while( have_rows('items', $term) ): the_row() ?>
						<li><?php the_sub_field('item', $term) ?></li>
						<?php endwhile ?>
						<?php endif ?>
					</ul>
					<a href="<?php the_sub_field('url_page', $term) ?>">See & Compare <i class="fas fa-arrow-right"></i></a>
				</div>
			</div>
			<?php endwhile ?>
			<?php endif ?>
		</div>
	</div>
</section> 
<div style="margin:2rem"></div>
<?php get_template_part('section/funfact') ?>

<section class="container section-padding">
	<div class="section-title">About Process</div>
	<?php if( have_rows('aproc', $term) ): ?>
	<?php while( have_rows('aproc', $term) ): the_row() ?>
	<div class="about-icon-box style-2">
		<div class="icon">
			<i class="fal fa-users"></i>
		</div>
		<div class="content">
			<h3><?php the_sub_field('title_proc', $term) ?></h3>
			<p><?php the_sub_field('content_proc', $term) ?></p>
		</div>
	</div>
	<?php endwhile ?>
	<?php endif ?>
</section>

<div class="faq-content">
	<div class="faq-accordion">
		<div id="accordion" class="accordion">
			<?php if( have_rows('faq', $term) ): ?>
			<?php while( have_rows('faq', $term) ): the_row() ?>
			<div class="card">
				<div class="card-header" id="faq<?php echo get_row_index() ?>">
					<p class="mb-0 text-capitalize">
						<a class="collapsed" role="button" data-toggle="collapse" aria-expanded="false" href="#faq-<?php echo get_row_index() ?>"><?php the_sub_field('title_faq', $term) ?></a>
					</h5>
				</div>
				<div id="faq-<?php echo get_row_index() ?>" class="collapse" data-parent="#accordion">
					<div class="card-body"><?php the_sub_field('text_description', $term) ?></div>
				</div>
			</div>
			<?php endwhile ?>
			<?php endif ?>
		</div>                        
	</div>
</div>
<?php get_footer() ?>