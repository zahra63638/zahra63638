<?php
include_once('inc/bootstrap.php');
register_nav_menus(array('main_menu'=>'Menu','footer_menu'=>'Footer Menu','footer_services_menu'=>'Footer Services Menu'));
add_theme_support('title-tag');
add_theme_support('post-thumbnails');