<?php get_header() ?>
<section class="page-banner-wrap bg-cover" style="background-image: url('<?php bloginfo('template_directory') ?>/assets/img/page-banner.jpg')">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-12 col-12">
                <div class="page-heading text-white">
                    <div class="page-title">
                        <h1>Faq</h1>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="faq-section section-padding">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 wow fadeInUp">
                <div class="faq-content">
                    <div class="faq-accordion">
                        <div id="accordion" class="accordion">
                            <div class="card">
                                <div class="card-header" id="faq1">
                                    <p class="mb-0 text-capitalize">
                                        <a class="collapsed" role="button" data-toggle="collapse" aria-expanded="false" href="#faq-1">
                                        How to donate on our site using your form?
                                        </a>
                                    </h5>
                                </div>
                                <div id="faq-1" class="collapse" data-parent="#accordion">
                                    <div class="card-body">
                                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec rhoncus dolor at libero ultricies ullamcorper vel ut dui. Maecenas sollicitudin risus non faucibus blandit. Nulla facilisi. 
                                    </div>
                                </div>
                            </div>
                            <div class="card">
                                <div class="card-header" id="faq2">
                                    <p class="mb-0 text-capitalize">
                                        <a class="collapsed" role="button" data-toggle="collapse" aria-expanded="true" href="#faq-2">
                                        How to became a volunteer in Zambia state?
                                        </a>
                                    </p>
                                </div>
                                <div id="faq-2" class="collapse show" data-parent="#accordion">
                                    <div class="card-body">
                                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec rhoncus dolor at libero ultricies ullamcorper vel ut dui. Maecenas sollicitudin risus non faucibus blandit. Nulla facilisi.
                                    </div>
                                </div>
                            </div>
                            <div class="card">
                                <div class="card-header" id="faq3">
                                    <p class="mb-0 text-capitalize">
                                        <a class="collapsed" role="button" data-toggle="collapse" aria-expanded="false" href="#faq-3">
                                        How can I give my clothes and other products?
                                        </a>
                                    </p>
                                </div>
                                <div id="faq-3" class="collapse" data-parent="#accordion">
                                    <div class="card-body">
                                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec rhoncus dolor at libero ultricies ullamcorper vel ut dui. Maecenas sollicitudin risus non faucibus blandit. Nulla facilisi.
                                    </div>
                                </div>
                            </div>
                        </div>                        
                    </div>
                </div>
            </div>
            <div class="col-lg-6 wow fadeInUp">
                <div class="faq-content">
                    <div class="faq-accordion">
                        <div id="accordion" class="accordion">
                            <div class="card">
                                <div class="card-header" id="faq1">
                                    <p class="mb-0 text-capitalize">
                                        <a class="collapsed" role="button" data-toggle="collapse" aria-expanded="false" href="#faq-1">
                                        How to donate on our site using your form?
                                        </a>
                                    </h5>
                                </div>
                                <div id="faq-1" class="collapse" data-parent="#accordion">
                                    <div class="card-body">
                                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec rhoncus dolor at libero ultricies ullamcorper vel ut dui. Maecenas sollicitudin risus non faucibus blandit. Nulla facilisi. 
                                    </div>
                                </div>
                            </div>
                            <div class="card">
                                <div class="card-header" id="faq2">
                                    <p class="mb-0 text-capitalize">
                                        <a class="collapsed" role="button" data-toggle="collapse" aria-expanded="true" href="#faq-2">
                                        How to became a volunteer in Zambia state?
                                        </a>
                                    </p>
                                </div>
                                <div id="faq-2" class="collapse show" data-parent="#accordion">
                                    <div class="card-body">
                                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec rhoncus dolor at libero ultricies ullamcorper vel ut dui. Maecenas sollicitudin risus non faucibus blandit. Nulla facilisi.
                                    </div>
                                </div>
                            </div>
                            <div class="card">
                                <div class="card-header" id="faq3">
                                    <p class="mb-0 text-capitalize">
                                        <a class="collapsed" role="button" data-toggle="collapse" aria-expanded="false" href="#faq-3">
                                        How can I give my clothes and other products?
                                        </a>
                                    </p>
                                </div>
                                <div id="faq-3" class="collapse" data-parent="#accordion">
                                    <div class="card-body">
                                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec rhoncus dolor at libero ultricies ullamcorper vel ut dui. Maecenas sollicitudin risus non faucibus blandit. Nulla facilisi.
                                    </div>
                                </div>
                            </div>
                        </div>                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php get_footer() ?>